const getNumUser = document.querySelector('#num-user')
const getGerarCores = document.querySelector('#gerarCores')
const getUpdateCores = document.querySelector('#updateCores')
const getClearCores = document.querySelector('#clearCores')

let numDigitado

getGerarCores.addEventListener('click', () => {
    numDigitado = getNumUser.value
    numDigitado = Number(numDigitado)

    if(getNumUser.value == ''){
        alert('Insira um valor')   
    }else if( !isNaN(numDigitado) ){
       //alert('Valor numerico inserido')  // O usuario digitou um valor  
        qtd = numDigitado
        geradorDeCores()
    }else{
        alert('Insira numero, não texto')
    }
    getNumUser.value = ''
    console.log(numDigitado)
})




getUpdateCores.addEventListener('click', () => {
    if(qtd > 0){
        numDigitado = Number(numDigitado)
        removerCores() 
        geradorDeCores()
        console.log(numDigitado) // debug
    }else{
        alert('Insira um valor')  
    }
})

getClearCores.addEventListener('click', function (){
    if(qtd > 0){
        removerCores()
        qtd = 0
    }else{
        alert('Insira um valor')  
    }
})


function removerCores() {
    const getBox = document.querySelectorAll('div.box')
    console.log(getBox) // debug

    for(n of getBox){
        n.remove()
    }
}