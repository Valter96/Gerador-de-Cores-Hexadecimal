let numAleatorio = 0, min = 0, max = 10, arrCorGerada = [], result
let qtd

function geraNum() {
    for(let i=0; i<6; i++){
        numAleatorio = Math.floor(Math.random() * (max-min) ) + min
        arrCorGerada.push(numAleatorio)
    }
}

function geradorDeCores(){
    
    for(let i = 0; i<qtd; i++){
    
        arrCorGerada = []
        arrCorGerada.splice(0, 0, "#")
        geraNum()
        result = arrCorGerada.join('')
        console.log(result)

        const getSection = document.querySelector('section')
        const creatDiv = document.createElement('div')
        const creatP = document.createElement('p')
        creatDiv.append(creatP)
        
        const textColor = document.createTextNode(result)
        creatDiv.setAttribute('class', 'box')
        creatP.appendChild(textColor)
        getSection.appendChild(creatDiv)

        creatDiv.style.background = result
    }
}




